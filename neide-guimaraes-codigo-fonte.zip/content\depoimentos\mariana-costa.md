---
name: "Mariana Costa"
text: "A Neide conduziu todo o processo com profissionalismo e atenção aos detalhes. Encontramos nosso imóvel em Ponta Negra com total segurança."
bairro: "Ponta Negra"
tipo_negociacao: "Comprou"
---
