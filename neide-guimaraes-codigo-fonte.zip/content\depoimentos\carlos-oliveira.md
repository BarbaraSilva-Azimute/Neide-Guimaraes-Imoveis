---
name: "Carlos Oliveira"
text: "Fiquei impressionado com a curadoria. Visitei apenas imóveis que realmente encaixavam no meu perfil, economizando muito tempo."
bairro: "Adrianópolis"
tipo_negociacao: "Alugou"
---
